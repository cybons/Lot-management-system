[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / hooks/ui/useTable

# hooks/ui/useTable

## Interfaces

- [PaginationState](interfaces/PaginationState.md)
- [SortState](interfaces/SortState.md)

## Type Aliases

- [SortDirection](type-aliases/SortDirection.md)

## Functions

- [useSelection](functions/useSelection.md)
- [useTable](functions/useTable.md)
