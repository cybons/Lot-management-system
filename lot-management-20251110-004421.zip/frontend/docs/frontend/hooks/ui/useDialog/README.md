[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / hooks/ui/useDialog

# hooks/ui/useDialog

## Functions

- [useConfirmDialog](functions/useConfirmDialog.md)
- [useDialog](functions/useDialog.md)
- [useDialogWithData](functions/useDialogWithData.md)
- [useMultipleDialogs](functions/useMultipleDialogs.md)
