[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / hooks/ui/useToast

# hooks/ui/useToast

## Interfaces

- [Toast](interfaces/Toast.md)

## Type Aliases

- [ToastVariant](type-aliases/ToastVariant.md)

## Functions

- [usePromiseToast](functions/usePromiseToast.md)
- [useSingleToast](functions/useSingleToast.md)
- [useToast](functions/useToast.md)
