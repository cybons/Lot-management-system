[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / hooks/mutations/useAllocationMutations

# hooks/mutations/useAllocationMutations

## Functions

- [useAutoAllocate](functions/useAutoAllocate.md)
- [useBulkCancelAllocations](functions/useBulkCancelAllocations.md)
- [useCancelAllAllocationsForLine](functions/useCancelAllAllocationsForLine.md)
- [useCancelAllocation](functions/useCancelAllocation.md)
- [useCreateAllocations](functions/useCreateAllocations.md)
