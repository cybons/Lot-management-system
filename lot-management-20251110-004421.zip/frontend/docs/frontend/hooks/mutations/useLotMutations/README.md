[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / hooks/mutations/useLotMutations

# hooks/mutations/useLotMutations

## Functions

- [useBulkCreateLots](functions/useBulkCreateLots.md)
- [useCreateLot](functions/useCreateLot.md)
- [useDeleteLot](functions/useDeleteLot.md)
- [useUpdateLot](functions/useUpdateLot.md)
- [useUpdateLotStatus](functions/useUpdateLotStatus.md)
