[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / hooks/mutations/useOrderMutations

# hooks/mutations/useOrderMutations

## Functions

- [useBulkCreateOrders](functions/useBulkCreateOrders.md)
- [useCreateOrder](functions/useCreateOrder.md)
- [useDeleteOrder](functions/useDeleteOrder.md)
- [useUpdateOrder](functions/useUpdateOrder.md)
- [useUpdateOrderStatus](functions/useUpdateOrderStatus.md)
