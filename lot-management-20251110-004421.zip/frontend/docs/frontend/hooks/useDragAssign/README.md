[**lot-management-frontend v1.0.0**](../../README.md)

***

[lot-management-frontend](../../README.md) / hooks/useDragAssign

# hooks/useDragAssign

## Interfaces

- [DragAssignRequest](interfaces/DragAssignRequest.md)
- [DragAssignResponse](interfaces/DragAssignResponse.md)

## Functions

- [useDragAssign](functions/useDragAssign.md)
