[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [hooks/api/useMastersQuery](../README.md) / useWarehouseOptions

# Function: useWarehouseOptions()

> **useWarehouseOptions**(): `object`[]

Defined in: [src/hooks/api/useMastersQuery.ts:218](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/hooks/api/useMastersQuery.ts#L218)

倉庫選択肢を生成

## Returns

`object`[]
