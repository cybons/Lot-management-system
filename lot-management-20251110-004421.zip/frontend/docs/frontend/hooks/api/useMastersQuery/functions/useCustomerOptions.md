[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [hooks/api/useMastersQuery](../README.md) / useCustomerOptions

# Function: useCustomerOptions()

> **useCustomerOptions**(): `object`[]

Defined in: [src/hooks/api/useMastersQuery.ts:205](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/hooks/api/useMastersQuery.ts#L205)

得意先選択肢を生成

## Returns

`object`[]
