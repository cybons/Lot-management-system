[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / hooks/api/useMastersQuery

# hooks/api/useMastersQuery

## Functions

- [createSelectOptions](functions/createSelectOptions.md)
- [useAllMastersQuery](functions/useAllMastersQuery.md)
- [useCustomerOptions](functions/useCustomerOptions.md)
- [useCustomerQuery](functions/useCustomerQuery.md)
- [useCustomersQuery](functions/useCustomersQuery.md)
- [useProductOptions](functions/useProductOptions.md)
- [useProductQuery](functions/useProductQuery.md)
- [useProductsQuery](functions/useProductsQuery.md)
- [useWarehouseOptions](functions/useWarehouseOptions.md)
- [useWarehouseQuery](functions/useWarehouseQuery.md)
- [useWarehousesQuery](functions/useWarehousesQuery.md)
