[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / hooks/api/useOrdersQuery

# hooks/api/useOrdersQuery

## Functions

- [useOrdersQuery](functions/useOrdersQuery.md)
