[**lot-management-frontend v1.0.0**](../../README.md)

***

[lot-management-frontend](../../README.md) / hooks/api

# hooks/api

## References

### createSelectOptions

Re-exports [createSelectOptions](useMastersQuery/functions/createSelectOptions.md)

***

### useAllMastersQuery

Re-exports [useAllMastersQuery](useMastersQuery/functions/useAllMastersQuery.md)

***

### useCustomerOptions

Re-exports [useCustomerOptions](useMastersQuery/functions/useCustomerOptions.md)

***

### useCustomerQuery

Re-exports [useCustomerQuery](useMastersQuery/functions/useCustomerQuery.md)

***

### useCustomersQuery

Re-exports [useCustomersQuery](useMastersQuery/functions/useCustomersQuery.md)

***

### useLotsQuery

Re-exports [useLotsQuery](useLotsQuery/functions/useLotsQuery.md)

***

### useOrdersQuery

Re-exports [useOrdersQuery](useOrdersQuery/functions/useOrdersQuery.md)

***

### useProductOptions

Re-exports [useProductOptions](useMastersQuery/functions/useProductOptions.md)

***

### useProductQuery

Re-exports [useProductQuery](useMastersQuery/functions/useProductQuery.md)

***

### useProductsQuery

Re-exports [useProductsQuery](useMastersQuery/functions/useProductsQuery.md)

***

### useWarehouseOptions

Re-exports [useWarehouseOptions](useMastersQuery/functions/useWarehouseOptions.md)

***

### useWarehouseQuery

Re-exports [useWarehouseQuery](useMastersQuery/functions/useWarehouseQuery.md)

***

### useWarehousesQuery

Re-exports [useWarehousesQuery](useMastersQuery/functions/useWarehousesQuery.md)
