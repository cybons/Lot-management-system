[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / hooks/api/useLotsQuery

# hooks/api/useLotsQuery

## Functions

- [useLotsQuery](functions/useLotsQuery.md)
