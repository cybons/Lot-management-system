[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / hooks/api/useForecastQuery

# hooks/api/useForecastQuery

## Functions

- [getForecasts](functions/getForecasts.md)
