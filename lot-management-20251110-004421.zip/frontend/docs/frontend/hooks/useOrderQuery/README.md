[**lot-management-frontend v1.0.0**](../../README.md)

***

[lot-management-frontend](../../README.md) / hooks/useOrderQuery

# hooks/useOrderQuery

## Interfaces

- [OrderDetail](interfaces/OrderDetail.md)
- [OrderLine](interfaces/OrderLine.md)

## Functions

- [useOrderQuery](functions/useOrderQuery.md)
