[**lot-management-frontend v1.0.0**](../../README.md)

***

[lot-management-frontend](../../README.md) / hooks/useLots

# hooks/useLots

## Functions

- [useLot](functions/useLot.md)
- [useLots](functions/useLots.md)
