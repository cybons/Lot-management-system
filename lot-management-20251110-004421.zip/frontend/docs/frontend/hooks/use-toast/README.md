[**lot-management-frontend v1.0.0**](../../README.md)

***

[lot-management-frontend](../../README.md) / hooks/use-toast

# hooks/use-toast

## Interfaces

- [ToastProps](interfaces/ToastProps.md)

## Functions

- [reducer](functions/reducer.md)
- [toast](functions/toast.md)
- [useToast](functions/useToast.md)
