[**lot-management-frontend v1.0.0**](../../README.md)

***

[lot-management-frontend](../../README.md) / hooks/useForecasts

# hooks/useForecasts

## Functions

- [useForecast](functions/useForecast.md)
- [useForecasts](functions/useForecasts.md)
