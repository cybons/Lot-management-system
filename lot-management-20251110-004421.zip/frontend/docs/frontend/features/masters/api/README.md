[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / features/masters/api

# features/masters/api

## Functions

- [getProducts](functions/getProducts.md)
- [getSuppliers](functions/getSuppliers.md)
- [getWarehouses](functions/getWarehouses.md)
