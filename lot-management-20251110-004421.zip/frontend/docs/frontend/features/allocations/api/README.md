[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / features/allocations/api

# features/allocations/api

## Type Aliases

- [AllocationInputItem](type-aliases/AllocationInputItem.md)
- [AllocationResult](type-aliases/AllocationResult.md)
- [CreateAllocationPayload](type-aliases/CreateAllocationPayload.md)

## Functions

- [cancelAllocation](functions/cancelAllocation.md)
- [createAllocations](functions/createAllocations.md)
