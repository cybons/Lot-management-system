[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [features/allocations/api](../README.md) / cancelAllocation

# Function: cancelAllocation()

> **cancelAllocation**(`allocationId`): `Promise`\<`void`\>

Defined in: [src/features/allocations/api.ts:41](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/allocations/api.ts#L41)

取消し（フックは戻り値を使っていないので void でOK）

## Parameters

### allocationId

`number`

## Returns

`Promise`\<`void`\>
