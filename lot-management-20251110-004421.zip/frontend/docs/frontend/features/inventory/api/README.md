[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / features/inventory/api

# features/inventory/api

## Functions

- [createLot](functions/createLot.md)
- [getLot](functions/getLot.md)
- [getLots](functions/getLots.md)
