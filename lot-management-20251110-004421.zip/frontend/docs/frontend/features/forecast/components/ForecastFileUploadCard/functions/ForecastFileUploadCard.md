[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [features/forecast/components/ForecastFileUploadCard](../README.md) / ForecastFileUploadCard

# Function: ForecastFileUploadCard()

> **ForecastFileUploadCard**(`__namedParameters`): `Element`

Defined in: [src/features/forecast/components/ForecastFileUploadCard.tsx:15](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/forecast/components/ForecastFileUploadCard.tsx#L15)

## Parameters

### \_\_namedParameters

[`ForecastFileUploadCardProps`](../type-aliases/ForecastFileUploadCardProps.md)

## Returns

`Element`
