[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [features/forecast/components/ForecastFileUploadCard](../README.md) / ForecastFileUploadCardProps

# Type Alias: ForecastFileUploadCardProps

> **ForecastFileUploadCardProps** = `object`

Defined in: [src/features/forecast/components/ForecastFileUploadCard.tsx:8](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/forecast/components/ForecastFileUploadCard.tsx#L8)

## Properties

### className?

> `optional` **className**: `string`

Defined in: [src/features/forecast/components/ForecastFileUploadCard.tsx:12](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/forecast/components/ForecastFileUploadCard.tsx#L12)

追加のクラス名

***

### onUpload()?

> `optional` **onUpload**: (`file`) => `void`

Defined in: [src/features/forecast/components/ForecastFileUploadCard.tsx:10](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/forecast/components/ForecastFileUploadCard.tsx#L10)

ファイル選択後のハンドラ

#### Parameters

##### file

`File`

#### Returns

`void`
