[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/forecast/components/ForecastFileUploadCard

# features/forecast/components/ForecastFileUploadCard

## Type Aliases

- [ForecastFileUploadCardProps](type-aliases/ForecastFileUploadCardProps.md)

## Functions

- [ForecastFileUploadCard](functions/ForecastFileUploadCard.md)
