[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [features/forecast/api](../README.md) / ForecastBulkRequest

# Type Alias: ForecastBulkRequest

> **ForecastBulkRequest** = [`paths`](../../../../types/api/interfaces/paths.md)\[`"/api/forecast/bulk"`\]\[`"post"`\]\[`"requestBody"`\]\[`"content"`\]\[`"application/json"`\]

Defined in: [src/features/forecast/api.ts:11](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/forecast/api.ts#L11)
