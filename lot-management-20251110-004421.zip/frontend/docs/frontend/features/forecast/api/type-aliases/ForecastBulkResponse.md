[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [features/forecast/api](../README.md) / ForecastBulkResponse

# Type Alias: ForecastBulkResponse

> **ForecastBulkResponse** = [`paths`](../../../../types/api/interfaces/paths.md)\[`"/api/forecast/bulk"`\]\[`"post"`\]\[`"responses"`\]\[`201`\]\[`"content"`\]\[`"application/json"`\]

Defined in: [src/features/forecast/api.ts:13](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/forecast/api.ts#L13)
