[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [features/forecast/api](../README.md) / ForecastListResponse

# Type Alias: ForecastListResponse

> **ForecastListResponse** = [`paths`](../../../../types/api/interfaces/paths.md)\[`"/api/forecast/list"`\]\[`"get"`\]\[`"responses"`\]\[`200`\]\[`"content"`\]\[`"application/json"`\]

Defined in: [src/features/forecast/api.ts:6](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/forecast/api.ts#L6)
