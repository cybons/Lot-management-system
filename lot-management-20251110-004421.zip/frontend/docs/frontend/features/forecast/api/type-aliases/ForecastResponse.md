[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [features/forecast/api](../README.md) / ForecastResponse

# Type Alias: ForecastResponse

> **ForecastResponse** = [`components`](../../../../types/api/interfaces/components.md)\[`"schemas"`\]\[`"ForecastResponse"`\]

Defined in: [src/features/forecast/api.ts:18](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/forecast/api.ts#L18)
