[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/orders/components/OrderLineHeader

# features/orders/components/OrderLineHeader

## Functions

- [OrderLineHeader](functions/OrderLineHeader.md)
