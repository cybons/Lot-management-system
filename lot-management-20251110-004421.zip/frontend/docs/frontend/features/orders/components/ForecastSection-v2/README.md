[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/orders/components/ForecastSection-v2

# features/orders/components/ForecastSection-v2

## Functions

- [ForecastSection](functions/ForecastSection.md)
