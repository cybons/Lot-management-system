[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [features/orders/components/ForecastSection-v2](../README.md) / ForecastSection

# Function: ForecastSection()

> **ForecastSection**(`__namedParameters`): `Element` \| `null`

Defined in: [src/features/orders/components/ForecastSection-v2.tsx:10](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/orders/components/ForecastSection-v2.tsx#L10)

## Parameters

### \_\_namedParameters

`Props`

## Returns

`Element` \| `null`
