[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/orders/components/LotListWithAllocation

# features/orders/components/LotListWithAllocation

## Functions

- [LotListWithAllocation](functions/LotListWithAllocation.md)
