[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/orders/components/WarehouseBadges

# features/orders/components/WarehouseBadges

## Functions

- [WarehouseBadges](functions/WarehouseBadges.md)
