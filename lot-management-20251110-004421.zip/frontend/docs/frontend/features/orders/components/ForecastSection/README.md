[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/orders/components/ForecastSection

# features/orders/components/ForecastSection

## Functions

- [ForecastSection](functions/ForecastSection.md)
