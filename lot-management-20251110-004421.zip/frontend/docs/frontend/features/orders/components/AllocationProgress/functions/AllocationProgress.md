[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [features/orders/components/AllocationProgress](../README.md) / AllocationProgress

# Function: AllocationProgress()

> **AllocationProgress**(`__namedParameters`): `Element`

Defined in: [src/features/orders/components/AllocationProgress.tsx:12](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/orders/components/AllocationProgress.tsx#L12)

## Parameters

### \_\_namedParameters

`Props`

## Returns

`Element`
