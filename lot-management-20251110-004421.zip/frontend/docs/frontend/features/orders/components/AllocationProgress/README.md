[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/orders/components/AllocationProgress

# features/orders/components/AllocationProgress

## Functions

- [AllocationProgress](functions/AllocationProgress.md)
