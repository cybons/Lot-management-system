[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/orders/components/OrderLineCard

# features/orders/components/OrderLineCard

## Functions

- [OrderLineCard](functions/OrderLineCard.md)

## References

### default

Renames and re-exports [OrderLineCard](functions/OrderLineCard.md)
