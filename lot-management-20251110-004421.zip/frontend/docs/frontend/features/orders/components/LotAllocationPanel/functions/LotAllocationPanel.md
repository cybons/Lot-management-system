[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [features/orders/components/LotAllocationPanel](../README.md) / LotAllocationPanel

# Function: LotAllocationPanel()

> **LotAllocationPanel**(`props`): `Element` \| `null`

Defined in: [src/features/orders/components/LotAllocationPanel.tsx:61](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/orders/components/LotAllocationPanel.tsx#L61)

## Parameters

### props

`Props`

## Returns

`Element` \| `null`
