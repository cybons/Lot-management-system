[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/orders/components/LotAllocationPanel

# features/orders/components/LotAllocationPanel

## Functions

- [LotAllocationPanel](functions/LotAllocationPanel.md)
