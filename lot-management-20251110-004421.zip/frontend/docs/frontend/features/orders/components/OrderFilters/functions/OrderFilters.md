[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [features/orders/components/OrderFilters](../README.md) / OrderFilters

# Function: OrderFilters()

> **OrderFilters**(`__namedParameters`): `Element`

Defined in: [src/features/orders/components/OrderFilters.tsx:11](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/orders/components/OrderFilters.tsx#L11)

## Parameters

### \_\_namedParameters

`Props`

## Returns

`Element`
