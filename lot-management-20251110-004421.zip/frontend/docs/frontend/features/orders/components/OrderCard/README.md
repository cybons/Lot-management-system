[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/orders/components/OrderCard

# features/orders/components/OrderCard

## Functions

- [OrderCard](functions/OrderCard.md)
