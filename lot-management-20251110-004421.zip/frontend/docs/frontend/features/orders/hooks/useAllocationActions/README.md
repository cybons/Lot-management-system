[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/orders/hooks/useAllocationActions

# features/orders/hooks/useAllocationActions

## Functions

- [useAllocationActions](functions/useAllocationActions.md)
