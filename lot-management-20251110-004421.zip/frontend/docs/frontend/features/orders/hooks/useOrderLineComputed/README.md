[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/orders/hooks/useOrderLineComputed

# features/orders/hooks/useOrderLineComputed

## Type Aliases

- [OrderLineSource](type-aliases/OrderLineSource.md)
- [OrderSource](type-aliases/OrderSource.md)

## Functions

- [useOrderLineComputed](functions/useOrderLineComputed.md)
