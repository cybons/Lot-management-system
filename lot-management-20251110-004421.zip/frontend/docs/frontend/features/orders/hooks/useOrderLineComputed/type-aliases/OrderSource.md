[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [features/orders/hooks/useOrderLineComputed](../README.md) / OrderSource

# Type Alias: OrderSource

> **OrderSource** = `Partial`\<[`OrderResponse`](../../../../../types/aliases/type-aliases/OrderResponse.md)\>

Defined in: [src/features/orders/hooks/useOrderLineComputed.ts:24](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/orders/hooks/useOrderLineComputed.ts#L24)
