[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/orders/hooks/useAllocations

# features/orders/hooks/useAllocations

## Functions

- [useCancelAllocations](functions/useCancelAllocations.md)
- [useCandidateLots](functions/useCandidateLots.md)
- [useCreateAllocations](functions/useCreateAllocations.md)
- [useReMatchOrder](functions/useReMatchOrder.md)
- [useSaveWarehouseAllocations](functions/useSaveWarehouseAllocations.md)
- [useUpdateOrderLineStatus](functions/useUpdateOrderLineStatus.md)
