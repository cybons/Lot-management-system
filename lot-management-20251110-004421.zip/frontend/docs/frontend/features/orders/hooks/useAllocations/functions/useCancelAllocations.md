[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [features/orders/hooks/useAllocations](../README.md) / useCancelAllocations

# Function: useCancelAllocations()

> **useCancelAllocations**(`orderLineId`): `UseMutationResult`\<\{ `message?`: `string`; `success?`: `boolean`; \}, `Error`, [`AllocationCancelRequest`](../../../../../types/aliases/type-aliases/AllocationCancelRequest.md), `unknown`\>

Defined in: [src/features/orders/hooks/useAllocations.ts:135](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/orders/hooks/useAllocations.ts#L135)

引当を取消

## Parameters

### orderLineId

`number` | `undefined`

## Returns

`UseMutationResult`\<\{ `message?`: `string`; `success?`: `boolean`; \}, `Error`, [`AllocationCancelRequest`](../../../../../types/aliases/type-aliases/AllocationCancelRequest.md), `unknown`\>
