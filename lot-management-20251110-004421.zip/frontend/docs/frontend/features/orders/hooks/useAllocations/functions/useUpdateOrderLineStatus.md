[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [features/orders/hooks/useAllocations](../README.md) / useUpdateOrderLineStatus

# Function: useUpdateOrderLineStatus()

> **useUpdateOrderLineStatus**(`orderLineId`): `UseMutationResult`\<\{ `message`: `string`; `new_status`: `string`; `order_line_id`: `number`; `success`: `boolean`; \}, `Error`, `string`, `unknown`\>

Defined in: [src/features/orders/hooks/useAllocations.ts:184](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/orders/hooks/useAllocations.ts#L184)

受注明細のステータスを更新

## Parameters

### orderLineId

`number`

## Returns

`UseMutationResult`\<\{ `message`: `string`; `new_status`: `string`; `order_line_id`: `number`; `success`: `boolean`; \}, `Error`, `string`, `unknown`\>
