[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [features/orders/hooks/useOrders](../README.md) / useOrdersWithAllocations

# Function: useOrdersWithAllocations()

> **useOrdersWithAllocations**(): `void`

Defined in: [src/features/orders/hooks/useOrders.ts:27](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/orders/hooks/useOrders.ts#L27)

受注明細（行）の配列を返す

## Returns

`void`
