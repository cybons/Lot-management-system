[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [features/orders/hooks/useOrders](../README.md) / useOrdersList

# Function: useOrdersList()

> **useOrdersList**(`params`): `UseQueryResult`\<`object`[], `Error`\>

Defined in: [src/features/orders/hooks/useOrders.ts:14](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/features/orders/hooks/useOrders.ts#L14)

## Parameters

### params

[`OrdersListParams`](../../../../../types/aliases/type-aliases/OrdersListParams.md)

## Returns

`UseQueryResult`\<`object`[], `Error`\>
