[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/orders/hooks/useOrders

# features/orders/hooks/useOrders

## Variables

- [queryKeys](variables/queryKeys.md)

## Functions

- [useOrderDetail](functions/useOrderDetail.md)
- [useOrders](functions/useOrders.md)
- [useOrdersList](functions/useOrdersList.md)
- [useOrdersWithAllocations](functions/useOrdersWithAllocations.md)
