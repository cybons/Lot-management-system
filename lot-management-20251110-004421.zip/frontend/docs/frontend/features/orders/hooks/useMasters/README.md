[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / features/orders/hooks/useMasters

# features/orders/hooks/useMasters

## Functions

- [useCustomerDefaultWarehouses](functions/useCustomerDefaultWarehouses.md)
