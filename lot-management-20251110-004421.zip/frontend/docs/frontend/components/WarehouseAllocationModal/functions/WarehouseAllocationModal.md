[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / [components/WarehouseAllocationModal](../README.md) / WarehouseAllocationModal

# Function: WarehouseAllocationModal()

> **WarehouseAllocationModal**(`__namedParameters`): `Element`

Defined in: [src/components/WarehouseAllocationModal.tsx:37](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/WarehouseAllocationModal.tsx#L37)

## Parameters

### \_\_namedParameters

`WarehouseAllocationModalProps`

## Returns

`Element`
