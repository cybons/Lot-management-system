[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [components/shared/CommonUI](../README.md) / EmptyState

# Function: EmptyState()

> **EmptyState**(`__namedParameters`): `Element`

Defined in: [src/components/shared/CommonUI.tsx:121](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/CommonUI.tsx#L121)

空のステート表示

## Parameters

### \_\_namedParameters

#### action?

`ReactNode`

#### description?

`string`

#### title?

`string` = `"データがありません"`

## Returns

`Element`
