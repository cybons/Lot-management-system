[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / components/shared/ErrorBoundary

# components/shared/ErrorBoundary

## Classes

- [ErrorBoundary](classes/ErrorBoundary.md)
