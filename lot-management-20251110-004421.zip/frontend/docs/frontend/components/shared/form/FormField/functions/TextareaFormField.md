[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/form/FormField](../README.md) / TextareaFormField

# Function: TextareaFormField()

> **TextareaFormField**(`__namedParameters`): `Element`

Defined in: [src/components/shared/form/FormField.tsx:112](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/form/FormField.tsx#L112)

## Parameters

### \_\_namedParameters

[`TextareaFormFieldProps`](../interfaces/TextareaFormFieldProps.md)

## Returns

`Element`
