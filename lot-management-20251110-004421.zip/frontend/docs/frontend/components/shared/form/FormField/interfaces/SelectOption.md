[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/form/FormField](../README.md) / SelectOption

# Interface: SelectOption

Defined in: [src/components/shared/form/FormField.tsx:152](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/form/FormField.tsx#L152)

## Properties

### label

> **label**: `string`

Defined in: [src/components/shared/form/FormField.tsx:154](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/form/FormField.tsx#L154)

***

### value

> **value**: `string`

Defined in: [src/components/shared/form/FormField.tsx:153](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/form/FormField.tsx#L153)
