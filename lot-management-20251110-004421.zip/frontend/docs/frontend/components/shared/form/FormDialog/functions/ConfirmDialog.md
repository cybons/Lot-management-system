[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/form/FormDialog](../README.md) / ConfirmDialog

# Function: ConfirmDialog()

> **ConfirmDialog**(`__namedParameters`): `Element`

Defined in: [src/components/shared/form/FormDialog.tsx:152](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/form/FormDialog.tsx#L152)

確認ダイアログ
(削除確認など、簡単な確認用)

## Parameters

### \_\_namedParameters

[`ConfirmDialogProps`](../interfaces/ConfirmDialogProps.md)

## Returns

`Element`
