[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / components/shared/form/FormDialog

# components/shared/form/FormDialog

## Interfaces

- [ConfirmDialogProps](interfaces/ConfirmDialogProps.md)
- [FormDialogProps](interfaces/FormDialogProps.md)

## Functions

- [ConfirmDialog](functions/ConfirmDialog.md)
- [FormDialog](functions/FormDialog.md)
