[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / components/shared/layout/PageContainer

# components/shared/layout/PageContainer

## Functions

- [PageContainer](functions/PageContainer.md)
