[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / components/shared/layout/Section

# components/shared/layout/Section

## Functions

- [Section](functions/Section.md)
