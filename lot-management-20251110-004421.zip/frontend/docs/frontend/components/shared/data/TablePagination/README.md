[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / components/shared/data/TablePagination

# components/shared/data/TablePagination

## Interfaces

- [SimplePaginationProps](interfaces/SimplePaginationProps.md)
- [TablePaginationProps](interfaces/TablePaginationProps.md)

## Functions

- [SimplePagination](functions/SimplePagination.md)
- [TablePagination](functions/TablePagination.md)
