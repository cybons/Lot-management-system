[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/data/TablePagination](../README.md) / TablePagination

# Function: TablePagination()

> **TablePagination**(`__namedParameters`): `Element`

Defined in: [src/components/shared/data/TablePagination.tsx:47](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/TablePagination.tsx#L47)

## Parameters

### \_\_namedParameters

[`TablePaginationProps`](../interfaces/TablePaginationProps.md)

## Returns

`Element`
