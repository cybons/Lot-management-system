[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/data/FilterField](../README.md) / SelectFilterField

# Function: SelectFilterField()

> **SelectFilterField**(`__namedParameters`): `Element`

Defined in: [src/components/shared/data/FilterField.tsx:136](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/FilterField.tsx#L136)

## Parameters

### \_\_namedParameters

[`SelectFilterFieldProps`](../interfaces/SelectFilterFieldProps.md)

## Returns

`Element`
