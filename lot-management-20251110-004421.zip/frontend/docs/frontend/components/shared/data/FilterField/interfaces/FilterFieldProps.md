[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/data/FilterField](../README.md) / FilterFieldProps

# Interface: FilterFieldProps

Defined in: [src/components/shared/data/FilterField.tsx:29](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/FilterField.tsx#L29)

## Properties

### children

> **children**: `ReactNode`

Defined in: [src/components/shared/data/FilterField.tsx:33](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/FilterField.tsx#L33)

子要素

***

### className?

> `optional` **className**: `string`

Defined in: [src/components/shared/data/FilterField.tsx:39](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/FilterField.tsx#L39)

クラス名

***

### description?

> `optional` **description**: `string`

Defined in: [src/components/shared/data/FilterField.tsx:35](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/FilterField.tsx#L35)

説明文

***

### htmlFor?

> `optional` **htmlFor**: `string`

Defined in: [src/components/shared/data/FilterField.tsx:37](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/FilterField.tsx#L37)

label要素のhtmlFor

***

### label

> **label**: `string`

Defined in: [src/components/shared/data/FilterField.tsx:31](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/FilterField.tsx#L31)

ラベル
