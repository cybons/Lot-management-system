[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/data/FilterField](../README.md) / CheckboxFilterField

# Function: CheckboxFilterField()

> **CheckboxFilterField**(`__namedParameters`): `Element`

Defined in: [src/components/shared/data/FilterField.tsx:273](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/FilterField.tsx#L273)

## Parameters

### \_\_namedParameters

[`CheckboxFilterFieldProps`](../interfaces/CheckboxFilterFieldProps.md)

## Returns

`Element`
