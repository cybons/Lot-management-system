[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/data/FilterField](../README.md) / SelectOption

# Interface: SelectOption

Defined in: [src/components/shared/data/FilterField.tsx:69](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/FilterField.tsx#L69)

## Properties

### label

> **label**: `string`

Defined in: [src/components/shared/data/FilterField.tsx:71](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/FilterField.tsx#L71)

***

### value

> **value**: `string`

Defined in: [src/components/shared/data/FilterField.tsx:70](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/FilterField.tsx#L70)
