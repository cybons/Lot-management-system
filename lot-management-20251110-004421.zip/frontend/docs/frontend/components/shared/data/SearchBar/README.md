[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / components/shared/data/SearchBar

# components/shared/data/SearchBar

## Interfaces

- [InstantSearchBarProps](interfaces/InstantSearchBarProps.md)
- [SearchBarProps](interfaces/SearchBarProps.md)

## Functions

- [InstantSearchBar](functions/InstantSearchBar.md)
- [SearchBar](functions/SearchBar.md)
