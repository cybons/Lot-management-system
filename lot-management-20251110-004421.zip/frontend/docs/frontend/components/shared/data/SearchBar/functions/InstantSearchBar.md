[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/data/SearchBar](../README.md) / InstantSearchBar

# Function: InstantSearchBar()

> **InstantSearchBar**(`__namedParameters`): `Element`

Defined in: [src/components/shared/data/SearchBar.tsx:127](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/SearchBar.tsx#L127)

即時反映版検索バー
(デバウンスなし)

## Parameters

### \_\_namedParameters

[`InstantSearchBarProps`](../interfaces/InstantSearchBarProps.md)

## Returns

`Element`
