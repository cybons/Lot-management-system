[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / components/shared/data/EmptyState

# components/shared/data/EmptyState

## Functions

- [EmptyState](functions/EmptyState.md)
