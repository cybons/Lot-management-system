[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/data/DataTable](../README.md) / DataTable

# Function: DataTable()

> **DataTable**\<`T`\>(`__namedParameters`): `Element`

Defined in: [src/components/shared/data/DataTable.tsx:80](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/DataTable.tsx#L80)

## Type Parameters

### T

`T` = `never`

## Parameters

### \_\_namedParameters

[`DataTableProps`](../interfaces/DataTableProps.md)\<`T`\>

## Returns

`Element`
