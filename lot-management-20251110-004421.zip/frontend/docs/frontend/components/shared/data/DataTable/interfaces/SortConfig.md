[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/data/DataTable](../README.md) / SortConfig

# Interface: SortConfig

Defined in: [src/components/shared/data/DataTable.tsx:42](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/DataTable.tsx#L42)

## Properties

### column

> **column**: `string`

Defined in: [src/components/shared/data/DataTable.tsx:43](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/DataTable.tsx#L43)

***

### direction

> **direction**: `"desc"` \| `"asc"`

Defined in: [src/components/shared/data/DataTable.tsx:44](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/DataTable.tsx#L44)
