[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / components/shared/data/DataTable

# components/shared/data/DataTable

## Interfaces

- [Column](interfaces/Column.md)
- [DataTableProps](interfaces/DataTableProps.md)
- [SortConfig](interfaces/SortConfig.md)

## Functions

- [DataTable](functions/DataTable.md)
