[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/data/FilterPanel](../README.md) / FilterPanel

# Function: FilterPanel()

> **FilterPanel**(`__namedParameters`): `Element`

Defined in: [src/components/shared/data/FilterPanel.tsx:39](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/FilterPanel.tsx#L39)

## Parameters

### \_\_namedParameters

[`FilterPanelProps`](../interfaces/FilterPanelProps.md)

## Returns

`Element`
