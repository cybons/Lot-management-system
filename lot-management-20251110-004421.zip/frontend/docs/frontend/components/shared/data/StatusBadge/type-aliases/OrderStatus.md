[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/data/StatusBadge](../README.md) / OrderStatus

# Type Alias: OrderStatus

> **OrderStatus** = `"open"` \| `"allocated"` \| `"partial"` \| `"shipped"` \| `"closed"` \| `"cancelled"` \| `"PENDING_PROCUREMENT"`

Defined in: [src/components/shared/data/StatusBadge.tsx:127](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/StatusBadge.tsx#L127)
