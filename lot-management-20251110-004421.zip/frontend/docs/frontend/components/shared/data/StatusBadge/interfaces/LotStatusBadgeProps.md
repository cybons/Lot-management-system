[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/data/StatusBadge](../README.md) / LotStatusBadgeProps

# Interface: LotStatusBadgeProps

Defined in: [src/components/shared/data/StatusBadge.tsx:96](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/StatusBadge.tsx#L96)

## Properties

### className?

> `optional` **className**: `string`

Defined in: [src/components/shared/data/StatusBadge.tsx:98](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/StatusBadge.tsx#L98)

***

### status

> **status**: `string`

Defined in: [src/components/shared/data/StatusBadge.tsx:97](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/StatusBadge.tsx#L97)
