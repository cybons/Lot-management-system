[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/data/StatusBadge](../README.md) / OrderStatusBadgeProps

# Interface: OrderStatusBadgeProps

Defined in: [src/components/shared/data/StatusBadge.tsx:172](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/StatusBadge.tsx#L172)

## Properties

### className?

> `optional` **className**: `string`

Defined in: [src/components/shared/data/StatusBadge.tsx:174](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/StatusBadge.tsx#L174)

***

### status

> **status**: `string`

Defined in: [src/components/shared/data/StatusBadge.tsx:173](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/StatusBadge.tsx#L173)
