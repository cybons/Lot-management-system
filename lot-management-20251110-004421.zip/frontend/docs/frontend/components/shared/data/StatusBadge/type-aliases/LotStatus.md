[**lot-management-frontend v1.0.0**](../../../../../README.md)

***

[lot-management-frontend](../../../../../README.md) / [components/shared/data/StatusBadge](../README.md) / LotStatus

# Type Alias: LotStatus

> **LotStatus** = `"available"` \| `"allocated"` \| `"shipped"` \| `"expired"` \| `"quarantine"`

Defined in: [src/components/shared/data/StatusBadge.tsx:66](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/shared/data/StatusBadge.tsx#L66)
