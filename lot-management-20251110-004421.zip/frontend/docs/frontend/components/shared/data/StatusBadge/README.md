[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / components/shared/data/StatusBadge

# components/shared/data/StatusBadge

## Interfaces

- [LotStatusBadgeProps](interfaces/LotStatusBadgeProps.md)
- [OrderStatusBadgeProps](interfaces/OrderStatusBadgeProps.md)
- [StatusBadgeProps](interfaces/StatusBadgeProps.md)

## Type Aliases

- [LotStatus](type-aliases/LotStatus.md)
- [OrderStatus](type-aliases/OrderStatus.md)

## Functions

- [LotStatusBadge](functions/LotStatusBadge.md)
- [OrderStatusBadge](functions/OrderStatusBadge.md)
- [StatusBadge](functions/StatusBadge.md)
