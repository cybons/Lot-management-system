[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / components/ui/button

# components/ui/button

## Interfaces

- [ButtonProps](interfaces/ButtonProps.md)

## Variables

- [Button](variables/Button.md)
- [buttonVariants](variables/buttonVariants.md)
