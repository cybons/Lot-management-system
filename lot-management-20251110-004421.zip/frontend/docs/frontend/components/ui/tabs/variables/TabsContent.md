[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [components/ui/tabs](../README.md) / TabsContent

# Variable: TabsContent

> `const` **TabsContent**: `ForwardRefExoticComponent`\<`Omit`\<`TabsContentProps` & `RefAttributes`\<`HTMLDivElement`\>, `"ref"`\> & `RefAttributes`\<`HTMLDivElement`\>\>

Defined in: [src/components/ui/tabs.tsx:38](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/ui/tabs.tsx#L38)
