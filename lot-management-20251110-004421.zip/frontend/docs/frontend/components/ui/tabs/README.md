[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / components/ui/tabs

# components/ui/tabs

## Variables

- [Tabs](variables/Tabs.md)
- [TabsContent](variables/TabsContent.md)
- [TabsList](variables/TabsList.md)
- [TabsTrigger](variables/TabsTrigger.md)
