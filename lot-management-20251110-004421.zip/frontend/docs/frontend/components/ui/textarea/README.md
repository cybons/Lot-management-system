[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / components/ui/textarea

# components/ui/textarea

## Interfaces

- [TextareaProps](interfaces/TextareaProps.md)

## Variables

- [Textarea](variables/Textarea.md)
