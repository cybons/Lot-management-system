[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [components/ui/textarea](../README.md) / Textarea

# Variable: Textarea

> `const` **Textarea**: `ForwardRefExoticComponent`\<[`TextareaProps`](../interfaces/TextareaProps.md) & `RefAttributes`\<`HTMLTextAreaElement`\>\>

Defined in: [src/components/ui/textarea.tsx:14](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/ui/textarea.tsx#L14)
