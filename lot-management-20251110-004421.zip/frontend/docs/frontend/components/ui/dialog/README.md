[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / components/ui/dialog

# components/ui/dialog

## Variables

- [Dialog](variables/Dialog.md)
- [DialogClose](variables/DialogClose.md)
- [DialogContent](variables/DialogContent.md)
- [DialogDescription](variables/DialogDescription.md)
- [DialogOverlay](variables/DialogOverlay.md)
- [DialogPortal](variables/DialogPortal.md)
- [DialogTitle](variables/DialogTitle.md)
- [DialogTrigger](variables/DialogTrigger.md)

## Functions

- [DialogFooter](functions/DialogFooter.md)
- [DialogHeader](functions/DialogHeader.md)
