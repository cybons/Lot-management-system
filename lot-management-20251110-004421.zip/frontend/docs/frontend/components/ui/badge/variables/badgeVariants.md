[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [components/ui/badge](../README.md) / badgeVariants

# Variable: badgeVariants()

> `const` **badgeVariants**: (`props?`) => `string`

Defined in: [src/components/ui/badge.tsx:6](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/ui/badge.tsx#L6)

## Parameters

### props?

ConfigVariants\<\{ variant: \{ default: string; secondary: string; destructive: string; outline: string; \}; \}\> & ClassProp

## Returns

`string`
