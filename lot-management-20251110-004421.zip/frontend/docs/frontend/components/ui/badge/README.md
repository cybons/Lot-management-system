[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / components/ui/badge

# components/ui/badge

## Interfaces

- [BadgeProps](interfaces/BadgeProps.md)

## Variables

- [badgeVariants](variables/badgeVariants.md)

## Functions

- [Badge](functions/Badge.md)
