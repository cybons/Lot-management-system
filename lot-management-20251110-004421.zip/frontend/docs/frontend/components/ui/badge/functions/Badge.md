[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [components/ui/badge](../README.md) / Badge

# Function: Badge()

> **Badge**(`__namedParameters`): `Element`

Defined in: [src/components/ui/badge.tsx:30](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/ui/badge.tsx#L30)

## Parameters

### \_\_namedParameters

[`BadgeProps`](../interfaces/BadgeProps.md)

## Returns

`Element`
