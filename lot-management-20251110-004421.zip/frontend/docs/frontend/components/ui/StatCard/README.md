[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / components/ui/StatCard

# components/ui/StatCard

## Functions

- [StatCard](functions/StatCard.md)
