[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / components/ui/icons

# components/ui/icons

## Variables

- [Edit](variables/Edit.md)
- [RefreshCcw](variables/RefreshCcw.md)
