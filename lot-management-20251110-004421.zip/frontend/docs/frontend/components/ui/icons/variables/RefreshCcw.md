[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [components/ui/icons](../README.md) / RefreshCcw

# Variable: RefreshCcw

> `const` **RefreshCcw**: `React.FC`\<`React.SVGProps`\<`SVGSVGElement`\>\>

Defined in: [src/components/ui/icons.tsx:3](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/ui/icons.tsx#L3)
