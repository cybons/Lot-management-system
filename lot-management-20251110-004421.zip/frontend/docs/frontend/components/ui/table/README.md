[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / components/ui/table

# components/ui/table

## Variables

- [Table](variables/Table.md)
- [TableBody](variables/TableBody.md)
- [TableCaption](variables/TableCaption.md)
- [TableCell](variables/TableCell.md)
- [TableFooter](variables/TableFooter.md)
- [TableHead](variables/TableHead.md)
- [TableHeader](variables/TableHeader.md)
- [TableRow](variables/TableRow.md)
