[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [components/ui/table](../README.md) / TableBody

# Variable: TableBody

> `const` **TableBody**: `ForwardRefExoticComponent`\<`HTMLAttributes`\<`HTMLTableSectionElement`\> & `RefAttributes`\<`HTMLTableSectionElement`\>\>

Defined in: [src/components/ui/table.tsx:22](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/ui/table.tsx#L22)
