[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / components/ui/select

# components/ui/select

## Variables

- [Select](variables/Select.md)
- [SelectContent](variables/SelectContent.md)
- [SelectGroup](variables/SelectGroup.md)
- [SelectItem](variables/SelectItem.md)
- [SelectLabel](variables/SelectLabel.md)
- [SelectScrollDownButton](variables/SelectScrollDownButton.md)
- [SelectScrollUpButton](variables/SelectScrollUpButton.md)
- [SelectSeparator](variables/SelectSeparator.md)
- [SelectTrigger](variables/SelectTrigger.md)
- [SelectValue](variables/SelectValue.md)
