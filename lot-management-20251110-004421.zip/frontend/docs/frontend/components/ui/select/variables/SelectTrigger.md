[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [components/ui/select](../README.md) / SelectTrigger

# Variable: SelectTrigger

> `const` **SelectTrigger**: `ForwardRefExoticComponent`\<`Omit`\<`SelectTriggerProps` & `RefAttributes`\<`HTMLButtonElement`\>, `"ref"`\> & `RefAttributes`\<`HTMLButtonElement`\>\>

Defined in: [src/components/ui/select.tsx:13](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/ui/select.tsx#L13)
