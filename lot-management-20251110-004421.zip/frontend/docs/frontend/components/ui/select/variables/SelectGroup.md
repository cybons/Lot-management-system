[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [components/ui/select](../README.md) / SelectGroup

# Variable: SelectGroup

> `const` **SelectGroup**: `ForwardRefExoticComponent`\<`SelectGroupProps` & `RefAttributes`\<`HTMLDivElement`\>\> = `SelectPrimitive.Group`

Defined in: [src/components/ui/select.tsx:9](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/ui/select.tsx#L9)
