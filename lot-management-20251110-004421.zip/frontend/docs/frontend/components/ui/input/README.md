[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / components/ui/input

# components/ui/input

## Variables

- [Input](variables/Input.md)
