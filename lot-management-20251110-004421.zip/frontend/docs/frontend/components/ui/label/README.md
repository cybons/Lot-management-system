[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / components/ui/label

# components/ui/label

## Variables

- [Label](variables/Label.md)
