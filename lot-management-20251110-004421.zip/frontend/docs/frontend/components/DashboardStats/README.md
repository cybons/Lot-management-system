[**lot-management-frontend v1.0.0**](../../README.md)

***

[lot-management-frontend](../../README.md) / components/DashboardStats

# components/DashboardStats

## Functions

- [DashboardStats](functions/DashboardStats.md)
