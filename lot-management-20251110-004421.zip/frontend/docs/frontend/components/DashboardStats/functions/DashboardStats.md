[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / [components/DashboardStats](../README.md) / DashboardStats

# Function: DashboardStats()

> **DashboardStats**(): `Element`

Defined in: [src/components/DashboardStats.tsx:8](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/DashboardStats.tsx#L8)

## Returns

`Element`
