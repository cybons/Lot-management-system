[**lot-management-frontend v1.0.0**](../../../../README.md)

***

[lot-management-frontend](../../../../README.md) / [components/common/InfoRow](../README.md) / InfoRow

# Function: InfoRow()

> **InfoRow**(`__namedParameters`): `Element`

Defined in: [src/components/common/InfoRow.tsx:9](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/components/common/InfoRow.tsx#L9)

## Parameters

### \_\_namedParameters

`Props`

## Returns

`Element`
