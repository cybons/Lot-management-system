[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / components/common/InfoRow

# components/common/InfoRow

## Functions

- [InfoRow](functions/InfoRow.md)
