[**lot-management-frontend v1.0.0**](../../README.md)

***

[lot-management-frontend](../../README.md) / factories/master-factory

# factories/master-factory

## Functions

- [createActiveWarehouse](functions/createActiveWarehouse.md)
- [createInactiveWarehouse](functions/createInactiveWarehouse.md)
- [createProduct](functions/createProduct.md)
- [createProducts](functions/createProducts.md)
- [createSupplier](functions/createSupplier.md)
- [createSuppliers](functions/createSuppliers.md)
- [createWarehouse](functions/createWarehouse.md)
- [createWarehouses](functions/createWarehouses.md)
