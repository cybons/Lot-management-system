[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / [factories/order-factory](../README.md) / createOrderLine

# Function: createOrderLine()

> **createOrderLine**(`overrides?`): [`OrderLineFactoryResult`](../type-aliases/OrderLineFactoryResult.md)

Defined in: [src/factories/order-factory.ts:44](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/factories/order-factory.ts#L44)

受注明細を生成

## Parameters

### overrides?

`Partial`\<[`OrderLineFactoryResult`](../type-aliases/OrderLineFactoryResult.md)\>

## Returns

[`OrderLineFactoryResult`](../type-aliases/OrderLineFactoryResult.md)
