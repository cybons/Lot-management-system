[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / [factories/order-factory](../README.md) / OrderLineFactoryResult

# Type Alias: OrderLineFactoryResult

> **OrderLineFactoryResult** = [`OrderLine`](../../../types/aliases/type-aliases/OrderLine.md) & `OrderLineFactoryExtras`

Defined in: [src/factories/order-factory.ts:20](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/factories/order-factory.ts#L20)
