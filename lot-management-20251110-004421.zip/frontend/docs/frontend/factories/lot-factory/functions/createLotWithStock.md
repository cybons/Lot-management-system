[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / [factories/lot-factory](../README.md) / createLotWithStock

# Function: createLotWithStock()

> **createLotWithStock**(`overrides?`): [`LotResponse`](../../../types/aliases/type-aliases/LotResponse.md)

Defined in: [src/factories/lot-factory.ts:45](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/factories/lot-factory.ts#L45)

在庫があるロットを生成

## Parameters

### overrides?

`Partial`\<[`LotResponse`](../../../types/aliases/type-aliases/LotResponse.md)\>

## Returns

[`LotResponse`](../../../types/aliases/type-aliases/LotResponse.md)
