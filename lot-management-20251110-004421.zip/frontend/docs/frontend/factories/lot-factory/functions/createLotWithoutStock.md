[**lot-management-frontend v1.0.0**](../../../README.md)

***

[lot-management-frontend](../../../README.md) / [factories/lot-factory](../README.md) / createLotWithoutStock

# Function: createLotWithoutStock()

> **createLotWithoutStock**(`overrides?`): [`LotResponse`](../../../types/aliases/type-aliases/LotResponse.md)

Defined in: [src/factories/lot-factory.ts:55](https://github.com/cybons-lab/Lot-management-system/blob/27136a70bad131ce7a63fc3b65b7329cb546f591/frontend/src/factories/lot-factory.ts#L55)

在庫切れロットを生成

## Parameters

### overrides?

`Partial`\<[`LotResponse`](../../../types/aliases/type-aliases/LotResponse.md)\>

## Returns

[`LotResponse`](../../../types/aliases/type-aliases/LotResponse.md)
