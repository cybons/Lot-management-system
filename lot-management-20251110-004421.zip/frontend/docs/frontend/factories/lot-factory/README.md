[**lot-management-frontend v1.0.0**](../../README.md)

***

[lot-management-frontend](../../README.md) / factories/lot-factory

# factories/lot-factory

## Functions

- [createExpiredLot](functions/createExpiredLot.md)
- [createExpiringLot](functions/createExpiringLot.md)
- [createLot](functions/createLot.md)
- [createLots](functions/createLots.md)
- [createLotWithoutStock](functions/createLotWithoutStock.md)
- [createLotWithStock](functions/createLotWithStock.md)
