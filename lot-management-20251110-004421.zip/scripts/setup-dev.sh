#!/bin/bash
# Dev environment setup script

echo "Setting up dev environment..."
