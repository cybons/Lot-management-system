#!/usr/bin/env python3
# Python (Pydantic) to TS type generator script
print("Generating types...")
