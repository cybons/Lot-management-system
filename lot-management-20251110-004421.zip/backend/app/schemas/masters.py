# backend/app/schemas/masters.py
"""
マスタ関連のPydanticスキーマ
"""

from decimal import Decimal
from typing import Optional

from pydantic import Field

from .base import BaseSchema


# --- Warehouse ---
class WarehouseBase(BaseSchema):
    warehouse_code: str
    warehouse_name: str
    address: Optional[str] = None
    is_active: int = 1


class WarehouseCreate(WarehouseBase):
    pass


class WarehouseUpdate(BaseSchema):
    warehouse_name: Optional[str] = None
    address: Optional[str] = None
    is_active: Optional[int] = 1


class WarehouseResponse(WarehouseBase):
    pass


# --- Supplier ---
class SupplierBase(BaseSchema):
    supplier_code: str
    supplier_name: str
    address: Optional[str] = None


class SupplierCreate(SupplierBase):
    pass


class SupplierUpdate(BaseSchema):
    supplier_name: Optional[str] = None
    address: Optional[str] = None


class SupplierResponse(SupplierBase):
    pass


# --- Customer ---
class CustomerBase(BaseSchema):
    customer_code: str
    customer_name: str
    address: Optional[str] = None


class CustomerCreate(CustomerBase):
    pass


class CustomerUpdate(BaseSchema):
    customer_name: Optional[str] = None
    address: Optional[str] = None


class CustomerResponse(CustomerBase):
    pass


# --- Product ---
class ProductBase(BaseSchema):
    product_code: str
    product_name: str
    supplier_code: Optional[str] = None
    customer_part_no: Optional[str] = None
    maker_item_code: Optional[str] = None
    supplier_item_code: Optional[str] = None
    packaging_qty: Decimal = Field(..., gt=Decimal("0"))
    packaging_unit: str = Field(..., min_length=1)
    internal_unit: str = Field(..., min_length=1)
    base_unit: str = "EA"
    packaging: Optional[str] = None
    assemble_div: Optional[str] = None
    next_div: Optional[str] = None
    ji_ku_text: Optional[str] = None
    kumitsuke_ku_text: Optional[str] = None
    shelf_life_days: Optional[int] = None
    requires_lot_number: bool = True
    delivery_place_id: Optional[int] = None
    delivery_place_name: Optional[str] = None
    shipping_warehouse_name: Optional[str] = None


class ProductCreate(ProductBase):
    pass


class ProductUpdate(BaseSchema):
    product_name: Optional[str] = None
    supplier_code: Optional[str] = None
    customer_part_no: Optional[str] = None
    maker_item_code: Optional[str] = None
    supplier_item_code: Optional[str] = None
    packaging_qty: Optional[Decimal] = Field(default=None, gt=Decimal("0"))
    packaging_unit: Optional[str] = None
    internal_unit: Optional[str] = None
    base_unit: Optional[str] = None
    packaging: Optional[str] = None
    assemble_div: Optional[str] = None
    next_div: Optional[str] = None
    ji_ku_text: Optional[str] = None
    kumitsuke_ku_text: Optional[str] = None
    shelf_life_days: Optional[int] = None
    requires_lot_number: Optional[bool] = None
    delivery_place_id: Optional[int] = None
    delivery_place_name: Optional[str] = None
    shipping_warehouse_name: Optional[str] = None


class ProductResponse(ProductBase):
    pass


# --- ProductUomConversion ---
class ProductUomConversionBase(BaseSchema):
    product_code: str
    source_unit: str
    source_value: float = 1.0
    internal_unit_value: float


class ProductUomConversionCreate(ProductUomConversionBase):
    pass


class ProductUomConversionUpdate(BaseSchema):
    source_value: Optional[float] = None
    internal_unit_value: Optional[float] = None


class ProductUomConversionResponse(ProductUomConversionBase):
    id: int


class MasterBulkLoadRequest(BaseSchema):
    """Bulk load payload for master data."""

    warehouses: list[WarehouseCreate] = Field(default_factory=list)
    suppliers: list[SupplierCreate] = Field(default_factory=list)
    customers: list[CustomerCreate] = Field(default_factory=list)
    products: list[ProductCreate] = Field(default_factory=list)


class MasterBulkLoadResponse(BaseSchema):
    """Bulk load result summary."""

    created: dict[str, list[str]] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)
