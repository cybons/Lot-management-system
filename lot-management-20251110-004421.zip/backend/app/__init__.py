# backend/app/__init__.py
"""
Lot Management System Application Package
"""

__version__ = "2.0.0"
__app_name__ = "ロット管理システム"
